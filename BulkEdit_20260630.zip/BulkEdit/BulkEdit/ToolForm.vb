﻿Imports System.Windows.Forms

Public Class ToolForm
    Inherits Form

    Public Enum ApplyMode
        ApplyDateOnly = 1
        ApplyPrice1Only = 2
        ApplyPrice2Only = 3
        ApplyAll = 4
    End Enum

    Public Event ApplyValuesRequested(mode As ApplyMode,
                                      applyDate As String,
                                      price1 As String,
                                      price2 As String)

    Private dtpApplyDate As DateTimePicker
    Private txtPrice1 As TextBox
    Private txtPrice2 As TextBox

    Private btnApplyDateOnly As Button
    Private btnApplyPrice1Only As Button
    Private btnApplyPrice2Only As Button
    Private btnApplyAll As Button
    Private btnUndo As Button
    Private btnRedo As Button

    Friend WithEvents lbl1 As Label
    Friend WithEvents lbl2 As Label
    Friend WithEvents lbl3 As Label

    Public Event UndoRequested()
    Public Event RedoRequested()

    Public Sub New()
        InitializeComponent()

        AddHandler Me.btnApplyDateOnly.Click, AddressOf btnApplyDateOnly_Click
        AddHandler Me.btnApplyPrice1Only.Click, AddressOf btnApplyPrice1Only_Click
        AddHandler Me.btnApplyPrice2Only.Click, AddressOf btnApplyPrice2Only_Click
        AddHandler Me.btnApplyAll.Click, AddressOf btnApplyAll_Click

        AddHandler btnUndo.Click, AddressOf btnUndo_Click
        AddHandler btnRedo.Click, AddressOf btnRedo_Click
    End Sub

    Private Sub InitializeComponent()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.dtpApplyDate = New System.Windows.Forms.DateTimePicker()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.txtPrice1 = New System.Windows.Forms.TextBox()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.txtPrice2 = New System.Windows.Forms.TextBox()
        Me.btnApplyDateOnly = New System.Windows.Forms.Button()
        Me.btnApplyPrice1Only = New System.Windows.Forms.Button()
        Me.btnApplyPrice2Only = New System.Windows.Forms.Button()
        Me.btnApplyAll = New System.Windows.Forms.Button()
        Me.btnUndo = New System.Windows.Forms.Button()
        Me.btnRedo = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbl1
        '
        Me.lbl1.Location = New System.Drawing.Point(15, 26)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(73, 18)
        Me.lbl1.TabIndex = 0
        Me.lbl1.Text = "適用年月日"
        Me.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'dtpApplyDate
        '
        Me.dtpApplyDate.Location = New System.Drawing.Point(100, 20)
        Me.dtpApplyDate.Name = "dtpApplyDate"
        Me.dtpApplyDate.Size = New System.Drawing.Size(118, 28)
        Me.dtpApplyDate.TabIndex = 1
        '
        'lbl2
        '
        Me.lbl2.Location = New System.Drawing.Point(15, 66)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(73, 18)
        Me.lbl2.TabIndex = 2
        Me.lbl2.Text = "授業給単価"
        Me.lbl2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtPrice1
        '
        Me.txtPrice1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPrice1.Location = New System.Drawing.Point(100, 60)
        Me.txtPrice1.Name = "txtPrice1"
        Me.txtPrice1.Size = New System.Drawing.Size(118, 28)
        Me.txtPrice1.TabIndex = 3
        '
        'lbl3
        '
        Me.lbl3.Location = New System.Drawing.Point(15, 106)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(73, 18)
        Me.lbl3.TabIndex = 4
        Me.lbl3.Text = "業務給単価"
        Me.lbl3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txtPrice2
        '
        Me.txtPrice2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtPrice2.Location = New System.Drawing.Point(100, 100)
        Me.txtPrice2.Name = "txtPrice2"
        Me.txtPrice2.Size = New System.Drawing.Size(118, 28)
        Me.txtPrice2.TabIndex = 5
        '
        'btnApplyDateOnly
        '
        Me.btnApplyDateOnly.Location = New System.Drawing.Point(235, 20)
        Me.btnApplyDateOnly.Name = "btnApplyDateOnly"
        Me.btnApplyDateOnly.Size = New System.Drawing.Size(60, 28)
        Me.btnApplyDateOnly.TabIndex = 6
        Me.btnApplyDateOnly.Text = "設定"
        '
        'btnApplyPrice1Only
        '
        Me.btnApplyPrice1Only.Location = New System.Drawing.Point(235, 60)
        Me.btnApplyPrice1Only.Name = "btnApplyPrice1Only"
        Me.btnApplyPrice1Only.Size = New System.Drawing.Size(60, 28)
        Me.btnApplyPrice1Only.TabIndex = 7
        Me.btnApplyPrice1Only.Text = "設定"
        '
        'btnApplyPrice2Only
        '
        Me.btnApplyPrice2Only.Location = New System.Drawing.Point(235, 100)
        Me.btnApplyPrice2Only.Name = "btnApplyPrice2Only"
        Me.btnApplyPrice2Only.Size = New System.Drawing.Size(60, 28)
        Me.btnApplyPrice2Only.TabIndex = 8
        Me.btnApplyPrice2Only.Text = "設定"
        '
        'btnApplyAll
        '
        Me.btnApplyAll.Location = New System.Drawing.Point(235, 140)
        Me.btnApplyAll.Name = "btnApplyAll"
        Me.btnApplyAll.Size = New System.Drawing.Size(60, 28)
        Me.btnApplyAll.TabIndex = 9
        Me.btnApplyAll.Text = "全部"
        '
        'btnUndo
        '
        Me.btnUndo.Location = New System.Drawing.Point(20, 140)
        Me.btnUndo.Name = "btnUndo"
        Me.btnUndo.Size = New System.Drawing.Size(80, 28)
        Me.btnUndo.TabIndex = 0
        Me.btnUndo.Text = "元に戻す"
        '
        'btnRedo
        '
        Me.btnRedo.Location = New System.Drawing.Point(120, 140)
        Me.btnRedo.Name = "btnRedo"
        Me.btnRedo.Size = New System.Drawing.Size(80, 28)
        Me.btnRedo.TabIndex = 1
        Me.btnRedo.Text = "やり直す"
        '
        'ToolForm
        '
        Me.ClientSize = New System.Drawing.Size(314, 181)
        Me.ControlBox = False
        Me.Controls.Add(Me.btnUndo)
        Me.Controls.Add(Me.btnRedo)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.dtpApplyDate)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.txtPrice1)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.txtPrice2)
        Me.Controls.Add(Me.btnApplyDateOnly)
        Me.Controls.Add(Me.btnApplyPrice1Only)
        Me.Controls.Add(Me.btnApplyPrice2Only)
        Me.Controls.Add(Me.btnApplyAll)
        Me.Font = New System.Drawing.Font("游ゴシック", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "ToolForm"
        Me.Text = "　設定"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Protected Overrides Sub OnShown(e As EventArgs)
        MyBase.OnShown(e)

        'Me.FormBorderStyle = FormBorderStyle.FixedSingle
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.MaximizeBox = False
        Me.MinimizeBox = False
    End Sub

    Protected Overrides Sub OnFormClosing(e As FormClosingEventArgs)
        If e.CloseReason = CloseReason.UserClosing Then
            e.Cancel = True
            Me.Hide()
            Return
        End If
        MyBase.OnFormClosing(e)
    End Sub

    Private Sub btnApplyDateOnly_Click(sender As Object, e As EventArgs)
        RaiseEvent ApplyValuesRequested(ApplyMode.ApplyDateOnly,
                                        dtpApplyDate.Value.ToString("yyyy-MM-dd"),
                                        txtPrice1.Text.Trim(),
                                        txtPrice2.Text.Trim())
    End Sub

    Private Sub btnApplyPrice1Only_Click(sender As Object, e As EventArgs)
        RaiseEvent ApplyValuesRequested(ApplyMode.ApplyPrice1Only,
                                        dtpApplyDate.Value.ToString("yyyy-MM-dd"),
                                        txtPrice1.Text.Trim(),
                                        txtPrice2.Text.Trim())
    End Sub

    Private Sub btnApplyPrice2Only_Click(sender As Object, e As EventArgs)
        RaiseEvent ApplyValuesRequested(ApplyMode.ApplyPrice2Only,
                                        dtpApplyDate.Value.ToString("yyyy-MM-dd"),
                                        txtPrice1.Text.Trim(),
                                        txtPrice2.Text.Trim())
    End Sub

    Private Sub btnApplyAll_Click(sender As Object, e As EventArgs)
        RaiseEvent ApplyValuesRequested(ApplyMode.ApplyAll,
                                        dtpApplyDate.Value.ToString("yyyy-MM-dd"),
                                        txtPrice1.Text.Trim(),
                                        txtPrice2.Text.Trim())
    End Sub

    Private Sub btnUndo_Click(sender As Object, e As EventArgs)
        RaiseEvent UndoRequested()
    End Sub

    Private Sub btnRedo_Click(sender As Object, e As EventArgs)
        RaiseEvent RedoRequested()
    End Sub
End Class
