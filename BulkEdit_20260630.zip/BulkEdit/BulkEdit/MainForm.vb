﻿Imports System.Windows.Forms

Public Class MainForm
    Inherits Form

    Private tool As ToolForm
    Private dlg As DialogForm

    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub InitializeComponent()
        Me.IsMdiContainer = True
        Me.Text = "MDI 親画面"
        Me.Width = 1300
        Me.Height = 800
    End Sub

    Private Sub MainForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dlg = New DialogForm()
        dlg.MdiParent = Me
        dlg.Show()

        tool = New ToolForm()
        tool.MdiParent = Me
        tool.Show()

        AddHandler tool.ApplyValuesRequested, AddressOf dlg.ApplyValues
        ' ダイアログ画面が動いたら追従
        AddHandler dlg.Move, AddressOf DialogMoved
        AddHandler dlg.Resize, AddressOf DialogMoved
        AddHandler tool.UndoRequested, AddressOf dlg.ExecuteUndo
        AddHandler tool.RedoRequested, AddressOf dlg.ExecuteRedo

        DockToolToDialog()

    End Sub

    Private Sub DialogMoved(sender As Object, e As EventArgs)
        DockToolToDialog()
    End Sub

    Private Sub DockToolToDialog()
        If dlg Is Nothing OrElse tool Is Nothing Then
            Return
        End If

        ' ダイアログ画面の右側にドッキング風に配置
        tool.Left = dlg.Left + dlg.Width + 2
        tool.Top = dlg.Top
        'tool.Height = dlg.Height

        tool.BringToFront()
    End Sub
End Class
