﻿Imports System.Windows.Forms

Public Class DialogForm
    Inherits Form

    Private dgvStaff As DataGridView
    Private btnUndo As Button
    Private btnRedo As Button

    Private Class UndoItem
        Public RowIndex As Integer
        Public ColumnName As String
        Public OldValue As Object
        Public NewValue As Object
    End Class

    Private UndoStack As New List(Of List(Of UndoItem))
    Private RedoStack As New List(Of List(Of UndoItem))

    Public Sub New()
        InitializeComponent()
    End Sub

    Public Sub ApplyValues(mode As ToolForm.ApplyMode,
                            applyDate As String,
                            price1 As String,
                            price2 As String)

        Dim currentSet As New List(Of UndoItem)()

        For Each cell As DataGridViewCell In dgvStaff.SelectedCells

            Dim row As DataGridViewRow = cell.OwningRow

            Select Case mode

                Case ToolForm.ApplyMode.ApplyDateOnly
                    currentSet.Add(New UndoItem With {
                        .RowIndex = row.Index,
                        .ColumnName = "ApplyDate",
                        .OldValue = row.Cells("ApplyDate").Value,
                        .NewValue = applyDate
                    })
                    row.Cells("ApplyDate").Value = applyDate

                Case ToolForm.ApplyMode.ApplyPrice1Only
                    currentSet.Add(New UndoItem With {
                        .RowIndex = row.Index,
                        .ColumnName = "Price1",
                        .OldValue = row.Cells("Price1").Value,
                        .NewValue = price1
                    })
                    row.Cells("Price1").Value = price1

                Case ToolForm.ApplyMode.ApplyPrice2Only
                    currentSet.Add(New UndoItem With {
                        .RowIndex = row.Index,
                        .ColumnName = "Price2",
                        .OldValue = row.Cells("Price2").Value,
                        .NewValue = price2
                    })
                    row.Cells("Price2").Value = price2

                Case ToolForm.ApplyMode.ApplyAll
                    currentSet.Add(New UndoItem With {
                        .RowIndex = row.Index,
                        .ColumnName = "ApplyDate",
                        .OldValue = row.Cells("ApplyDate").Value,
                        .NewValue = applyDate
                    })
                    currentSet.Add(New UndoItem With {
                        .RowIndex = row.Index,
                        .ColumnName = "Price1",
                        .OldValue = row.Cells("Price1").Value,
                        .NewValue = price1
                    })
                    currentSet.Add(New UndoItem With {
                        .RowIndex = row.Index,
                        .ColumnName = "Price2",
                        .OldValue = row.Cells("Price2").Value,
                        .NewValue = price2
                    })

                    row.Cells("ApplyDate").Value = applyDate
                    row.Cells("Price1").Value = price1
                    row.Cells("Price2").Value = price2

            End Select

        Next

        If currentSet.Count > 0 Then
            UndoStack.Add(currentSet)
            RedoStack.Clear() ' 新しい操作が入ったら Redo は破棄
        End If

    End Sub

    Private Sub btnUndo_Click(sender As Object, e As EventArgs)
        If UndoStack.Count = 0 Then
            MessageBox.Show("元に戻す内容がありません。")
            Return
        End If

        Dim lastSet As List(Of UndoItem) = UndoStack(UndoStack.Count - 1)
        UndoStack.RemoveAt(UndoStack.Count - 1)

        Dim redoSet As New List(Of UndoItem)()

        For Each item As UndoItem In lastSet
            Dim row = dgvStaff.Rows(item.RowIndex)
            Dim cell = row.Cells(item.ColumnName)

            Dim currentValue As Object = cell.Value

            redoSet.Add(New UndoItem With {
                .RowIndex = item.RowIndex,
                .ColumnName = item.ColumnName,
                .OldValue = currentValue,
                .NewValue = item.OldValue
            })

            cell.Value = item.OldValue
        Next

        RedoStack.Add(redoSet)
    End Sub

    Private Sub btnRedo_Click(sender As Object, e As EventArgs)
        If RedoStack.Count = 0 Then
            MessageBox.Show("やり直す内容がありません。")
            Return
        End If

        Dim lastSet As List(Of UndoItem) = RedoStack(RedoStack.Count - 1)
        RedoStack.RemoveAt(RedoStack.Count - 1)

        Dim undoSet As New List(Of UndoItem)()

        For Each item As UndoItem In lastSet
            Dim row = dgvStaff.Rows(item.RowIndex)
            Dim cell = row.Cells(item.ColumnName)

            Dim currentValue As Object = cell.Value

            undoSet.Add(New UndoItem With {
                .RowIndex = item.RowIndex,
                .ColumnName = item.ColumnName,
                .OldValue = currentValue,
                .NewValue = item.NewValue
            })

            cell.Value = item.NewValue
        Next

        UndoStack.Add(undoSet)
    End Sub

    Public Sub ExecuteUndo()
        btnUndo_Click(Nothing, Nothing)
    End Sub

    Public Sub ExecuteRedo()
        btnRedo_Click(Nothing, Nothing)
    End Sub

    Private Sub InitializeComponent()
        Me.Text = "担当者単価設定"
        Me.Width = 900
        Me.Height = 650

        dgvStaff = New DataGridView()
        dgvStaff.Left = 10
        dgvStaff.Top = 10
        dgvStaff.Width = 850
        dgvStaff.Height = 500
        dgvStaff.SelectionMode = DataGridViewSelectionMode.CellSelect
        dgvStaff.MultiSelect = True
        dgvStaff.AllowUserToAddRows = False

        dgvStaff.Columns.Add("StaffCode", "担当者コード")
        dgvStaff.Columns.Add("ApplyDate", "適用日")
        dgvStaff.Columns.Add("Price1", "単価1")
        dgvStaff.Columns.Add("Price2", "単価2")

        For i As Integer = 1 To 10
            dgvStaff.Rows.Add("S" & i.ToString("000"),
                              "2024-01-01",
                              "1000",
                              "2000")
        Next

        btnUndo = New Button()
        btnUndo.Left = 10
        btnUndo.Top = 520
        btnUndo.Width = 120
        btnUndo.Text = "元に戻す"
        AddHandler btnUndo.Click, AddressOf btnUndo_Click

        btnRedo = New Button()
        btnRedo.Left = 140
        btnRedo.Top = 520
        btnRedo.Width = 120
        btnRedo.Text = "やり直し"
        AddHandler btnRedo.Click, AddressOf btnRedo_Click

        Me.Controls.Add(dgvStaff)
        Me.Controls.Add(btnUndo)
        Me.Controls.Add(btnRedo)
    End Sub

End Class
